namespace GymManager.Domain.Interfaces
{
    public interface IMenuStrategy
    {
        void ShowMenu();
    }
}