namespace GymManager.Domain.Models;

public enum EQType
{
    Cardio,
    Strength,
    Flexibility,
    Misc
}